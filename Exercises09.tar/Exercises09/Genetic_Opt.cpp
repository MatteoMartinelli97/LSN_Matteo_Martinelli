/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <iomanip>
#include <numeric>
#include "Genetic_Opt.h"

using namespace std;

/*
//Sintax for time_calculation
#include <chrono>
using namespace std::chrono;

auto start = high_resolution_clock::now();

auto stop = high_resolution_clock::now();
auto duration = duration_cast<nanoseconds>(stop-start);
cout << "Time of Create a new_population= " << duration.count() << endl;
*/ 
int main (int argc, char *argv[]){

	Input();
	if (Check_val) return -1;

	for (int igen=1; igen<=ngen; ++igen) {		//cycle over generation number
		if (igen%100 == 0)cout << "Generation " << igen << endl;
		New_Population.resize(0);				//reset New_Population size (must do beacuse Crossover uses push_back)
		for (int ipop=0; ipop<npop-1; ipop+=2) {	//cycle over couples (each couple gives new couple)
		//Select parents and crossover
			Select_Parents();
			Crossover(dad_idx, mum_idx);
		//Try genetic_mutation
			Genetic_Mutation(ipop);
			Genetic_Mutation(ipop+1);
		//Check if everything is ok with new paths
			if (Population[ipop].Check()) return -1;
			if (Population[ipop+1].Check()) return -1;
		}

	//Re-assign Population (must do because sort and parents use it)
		Population = New_Population;
	//Eventually add a new path (best till now)
	//no problem in population has one path more, all cycle are till npop
		Elitary_Cameo ();
	//Sort
		Path_Sort();
	//Fill Length vector for next parents selection and compute mean of first half
		Fill_Length();
	//Check if best_path improves
		if (Population[0].GetLength(dist) < Best_Path.GetLength(dist)) Best_Path = Population[0];	
	//Print top 10
		if (igen%1000 == 0) Print_Best_Length(10);
		Print(igen);
		Print_Best_Path_Coord ();
	}
//Print final result of best path (of all simulations)
	cout << "Total mutation performed = " << tot_mut << endl;
	cout << "Best path length = " << Best_Path.GetLength(dist) << endl;
	Print_Best_Path_Coord ();
//File with number of selection per index (ordered paths)
	ofstream WriteBin;
	WriteBin.open("bin.out");
	for (int i=0; i<npop; i++) WriteBin << i << "\t" << bin[i] << endl;
	WriteBin.close();

	rnd.SaveSeed();
	delete [] x;
	delete [] y;	
	for (int i=0; i<2; ++i) delete [] dist[i];
	delete [] bin;
return 0;
}


void Input() {
	ifstream ReadInput;
	
	rnd.Initialize();
	
	cout << "Genetic Algorithm		" << endl;
	cout << "Travelling Salesman Problem		" << endl << endl;
	
	ReadInput.open("input.dat");

	ReadInput >> ncts;
	cout << "There are " << ncts << " cities to visit	"  << endl;


	ReadInput >> npop;
	cout << "The program uses a population of " << npop << " paths" << endl;
	cout << "Distances are calculated with L^2 norm" << endl;

	ReadInput >> ngen;

	ReadInput >> geometry;

	ReadInput.close();
//Initialize vector of lengths
	Sum_Probability.resize(npop);
	mean_l = 0;
	best_l = 0;
//Initialize value of total mutations
	tot_mut = 0;
//Initialize bin
	bin = new int [npop];
	for (int i=0; i<npop; ++i) bin[i] = 0;
//Initialize value for checking moves	
	Check_val = false;

//Vector of population of random paths
	for (int i=0; i<npop; ++i) {
		Path start_path(ncts);
		Population.push_back(start_path);
		Check_val = Population[i].Check();
		if (Check_val) return;	
	}


//Vectors of cities coordinates
x = new double [ncts];
y = new double [ncts];
ofstream WriteCts;
	if (geometry == 0) {
		cout << "Cities are displayed on a circle" << endl;
		geo_name = "Circle";
		WriteCts.open(geo_name +"/cts_pos.out");
		//Circle dispositions
		for (int i=0; i<ncts; ++i) {	
			double theta = 2.0*rnd.Angle();
			x[i] = cos(theta);
			y[i] = sin(theta);
			WriteCts << i << "\t" << x[i] << "\t" << y[i] << endl;
		}
	} else {
		cout << "Cities are displayed inside a square" << endl;
		geo_name = "Square";
		WriteCts.open(geo_name +"/cts_pos.out");
		//Inside square disposition
		for (int i=0; i<ncts; ++i) {	
			x[i] = rnd.Rannyu(0.0, 1.0);
			y[i] = rnd.Rannyu(0.0, 1.0);
			WriteCts << i << "\t" << x[i] << "\t" << y[i] << endl;
		}
	}
WriteCts.close();

//If existing file of mean_l and best_l, remove
	string command = "rm " + geo_name + "/*length.out";
	const char* tcommand = command.c_str();
	system(tcommand);

	dist = new double* [ncts];
	for (int i=0; i<ncts; ++i) dist[i] = new double [ncts];
//Fill distances matrix (Dij = distance between city i-j = j-i)
//save all distances to optimize calulation
	for (int i=0; i<ncts; ++i) {
		for (int j=i; j<ncts; ++j) {
			double x2 = (x[i]-x[j])*(x[i]-x[j]);
			double y2 = (y[i]-y[j])*(y[i]-y[j]);
			dist[i][j] = x2 + y2;		//Symmetric matrix
			dist[j][i] = x2 + y2;
		}
	}
	cout << "Starting population generated" << endl;

//Order Paths and print top10
	Path_Sort();
	Print_Best_Length(10);
//Initialize Best_Path
	Best_Path = Population[0];
//Fill vector of lengths
	Fill_Length();
	Print(0);
}

//Sorting population in order of length
void Path_Sort () {
	sort(Population.begin(), Population.end(), Cmp_length);
	return;
}

//Returns true if first_length < second_length, needed in sort algorithm
bool Cmp_length (Path first, Path second) {
	if (first.GetLength(dist) < second.GetLength(dist)) return true;
	return false;
}

void Fill_Length () {
	double Ltot = 0.0;
//Probability proportional to inverse of length
	double prob = 0;
	for (int i=0; i<npop; ++i) {
		double length = Population[i].GetLength(dist);
		Ltot += length;
		prob += 1.0/length;
		Sum_Probability [i] = prob;
		if (i == 0) best_l = length;
		if (i == npop/2-1) mean_l = Ltot/(npop*0.5);
	}
}

void Select_Parents () {
	int min_idx = 0;
	int max_idx = npop-1;
	int mid_idx = 0;

	double d = rnd.Rannyu(0.0, Sum_Probability[npop-1]);
//Search dad_idx
	if (d < Sum_Probability[0]) dad_idx = 0;
	else {
		do {
			mid_idx = min_idx +(max_idx - min_idx)*0.5;
			if (d < Sum_Probability[mid_idx]) max_idx = mid_idx;
			else min_idx = mid_idx;
		} while ((max_idx-min_idx) != 1);

		dad_idx = max_idx;
	}

	//Reset indexes
	min_idx = 0;
	max_idx = npop-1;
	mid_idx = 0;

	double m = rnd.Rannyu(0.0, Sum_Probability[npop-1]);
//Search mum_idx
	if (m < Sum_Probability[0]) mum_idx = 0; 
	else {
		do {
			mid_idx = min_idx + (max_idx - min_idx)*0.5;
			if (m < Sum_Probability[mid_idx]) max_idx = mid_idx;
			else min_idx = mid_idx;
		} while (max_idx-min_idx != 1);

		mum_idx = max_idx;
	}
	if (mum_idx == dad_idx) mum_idx = (mum_idx+1)%ncts;
	return;
}


void Genetic_Mutation (int path_idx) {
	int mutation_type = rnd.Rannyu(0, 100);
	if (mutation_type > 9) return;		//Total of 10% mutation probability, each with 2%
	mutation_type = mutation_type%5;
	tot_mut++;
	if (mutation_type == 0) {			//Swap 2 random cities
		int cty_1 = rnd.Rannyu(0, ncts);
		int cty_2 = rnd.Rannyu(0, ncts);
		New_Population[path_idx].Swap(cty_1, cty_2);
	}
	if (mutation_type == 1) {			//Swap m random cities 
		int cty_1 = rnd.Rannyu(0, ncts);
		int m = rnd.Rannyu(0, ncts/2);
		int cty_2 = rnd.Rannyu(0, ncts-2*m+1);
		New_Population[path_idx].Swap(cty_1, cty_2, m);			//(idx city1, idx to sum to city one to obtain city 2, m)
	}
	if (mutation_type == 2) {			//Shift +n all cities
		int plus_shift = rnd.Rannyu(0, ncts);
		New_Population[path_idx].Shift(plus_shift);
	}
	if (mutation_type == 3) {			//Shift +n, m cities from cty_1
		int cty_1 = rnd.Rannyu(0, ncts);
		int plus_shift = rnd.Rannyu(0, ncts);
		int m = rnd.Rannyu(0, plus_shift);
		New_Population[path_idx].Shift(plus_shift, m, cty_1);
	}
	if (mutation_type == 4) {					//Reverse m random cities from cty1
		int cty_1 = rnd.Rannyu(0, ncts);
		int m = rnd.Rannyu(0, ncts);
		New_Population[path_idx].Reverse(cty_1, m);
	}


	return;
}

void Crossover (int d, int m) {


	double Cross_p = rnd.Rannyu();		//Crossover yes or no
	if (Cross_p >=0.8) {
		New_Population.push_back(Population[d]);
		New_Population.push_back(Population[m]);
		bin[dad_idx]++;
		bin[mum_idx]++;
		return;
	}


	Path dad = Population[d];
	Path mum = Population[m];
	Path son (ncts);
	Path daughter(ncts);
	Check_val = daughter.Check();
	if (Check_val) return;
	int cut_pos = rnd.Rannyu(0, ncts);

//First genes
	copy (dad.GetStart(), dad.GetStart() + cut_pos, son.GetStart());
	copy (mum.GetStart(), mum.GetStart() + cut_pos, daughter.GetStart());

//Create son
	vector <Gene> Last_genes;
	for (int i=cut_pos; i<ncts; ++i) {		//cycle over last dad genes
		Gene consort_gene;
		for (int j=0; j<ncts; ++j) {		
			if (dad.GetPath()[i] == mum.GetPath()[j]) {							//find their indexes in mum cromosomes
				consort_gene.Write_Gene(dad.GetPath()[i], j);		//put index in the order I found
				Last_genes.push_back(consort_gene);
				break;
			}
		}
	}
	
	sort(Last_genes.begin(), Last_genes.end(), Cmp_genes); 	//order genes mumlike

	//cycle over last mum genes ordered
	for (int i=cut_pos; i<ncts; ++i) son.WriteGene(Last_genes[i-cut_pos].Get_Gene(), i);	//write last genes, ordered
	Check_val = son.Check();
	if (Check_val) return;
	New_Population.push_back(son);


//Create daughter
	//Reset last genes
	Last_genes.resize(0);
	for (int i=cut_pos; i<ncts; ++i) {		//cycle over last mum genes
		Gene consort_gene;
		for (int j=0; j<ncts; ++j) {		
			if (mum.GetPath()[i] == dad.GetPath()[j]) {						//find their indexes in dad cromosomes
				consort_gene.Write_Gene(mum.GetPath()[i], j);	//put index in the order
				Last_genes.push_back(consort_gene);
				break;
			}
		}
	}
	
	sort(Last_genes.begin(), Last_genes.end(), Cmp_genes); //order genes dadlike

	//cycle over last dad genes ordered
	for (int i=cut_pos; i<ncts; ++i) daughter.WriteGene(Last_genes[i-cut_pos].Get_Gene(), i);	//write last genes,  ordered
	Check_val = daughter.Check();
	if (Check_val) return;
	New_Population.push_back(daughter);

	bin[dad_idx]++;
	bin[mum_idx]++;
	return;
}

	
//Returns true if first gene is before second in other parent cromosome, needed in sort algorithm
bool Cmp_genes (Gene first, Gene second) {
	if (first.Get_Pos() < second.Get_Pos()) return true;
	return false;
}

void Elitary_Cameo () {
	double p = rnd.Rannyu();
	if (p<0.1) New_Population.push_back(Best_Path);
	return;
}
	
void Print_Best_Length (int top) {
	for (int i=0; i<top; ++i) cout << i+1 << "\tl^2 = " << Population[i].GetLength(dist) << endl;
	return;
}

void Print_Best_Path_Coord () {
	ofstream WriteBPath;
	WriteBPath.open(geo_name + "/best_path.out");
	for (int i=0; i<ncts; ++i) WriteBPath << Best_Path.GetPath()[i] << "\t" << x[Best_Path.GetPath()[i]] << "\t" << y[Best_Path.GetPath()[i]] << endl;
	WriteBPath << Best_Path.GetPath()[0] << "\t" << x[Best_Path.GetPath()[0]] << "\t" << y[Best_Path.GetPath()[0]] << endl;
	return;
}

void Print (int igen) {
	ofstream BestLength, AveLength;
	BestLength.open(geo_name + "/best_length.out", ios::app);	
	AveLength.open(geo_name + "/ave_length.out", ios::app);
	BestLength << igen << "\t" << best_l << endl;
	AveLength << igen << "\t" << mean_l << endl;
	return;
}	
	

/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
