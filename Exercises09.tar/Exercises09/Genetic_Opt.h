/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
#ifndef __Genetic_Alg__
#define __Genetic_Alg__

#include <vector>
#include <algorithm>
#include <cstring> 
#include <string>
#include "random.h"
#include "path.h"

using namespace std;

//Random generator
Random rnd;

//parametersof population
int ncts, npop;
vector <Path> Population; 	//vector of population of  cities (== path)
vector <Path> New_Population;	//vector of new cities(crossover)
Path Best_Path;
vector <double> Sum_Probability;
double mean_l;
double best_l;

//parents properties
int dad_idx, mum_idx;

//simulation parameters
int ngen;
int tot_mut;
int* bin;

//geometry parameters
int geometry;
string geo_name;
double** dist;
double* x;
double* y;

//Check parameters
bool Check_val;

class Gene {
	private:
	int _gene;
	int _pos;
	
	public:	
	Gene() {}
	~Gene() {}
	void Write_Gene(int gene, int pos);
	int Get_Gene() {return _gene;};
	int Get_Pos() {return _pos;};
};

void Gene::Write_Gene (int gene, int pos) {
	_gene = gene;
	_pos = pos;
}

void Input();
void Check(int);
void Path_Sort ();
bool Cmp_length (Path, Path);
void Fill_Length ();
void Select_Parents();
double Length_sum (Path first, Path second);
void Genetic_Mutation (int path_idx);
void Crossover (int d, int m);
bool Cmp_genes (Gene first, Gene  second);
void Elitary_Cameo();
void Print_Best_Length (int top);
void Print_Best_Path_Coord ();
void Print (int igen);
#endif
/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
