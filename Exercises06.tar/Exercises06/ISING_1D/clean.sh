rm -rf output.*
rm -rf config.final
