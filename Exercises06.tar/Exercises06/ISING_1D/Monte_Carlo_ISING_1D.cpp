/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/

#include <iostream>
#include <fstream>
#include <ostream>
#include <cmath>
#include <iomanip>
#include "Monte_Carlo_ISING_1D.h"

#define MAG_MEAS

using namespace std;

int main() { 
	Input(); //Inizialization
	for(int iblk=1; iblk <= nblk; ++iblk) { 
		//Simulation
		Reset(iblk);   //Reset block averages
		for(int istep=1; istep <= nstep; ++istep) {
			Move(metro);
			Measure();
			Accumulate(); //Update block averages
		}
		Averages(iblk);   //Print results for current block
	}
	ConfFinal(); //Write final configuration

return 0;
}


void Input(void) {
	ifstream ReadInput;

	cout << "Classic 1D Ising model             " << endl;
	cout << "Monte Carlo simulation             " << endl << endl;
	cout << "Nearest neighbour interaction      " << endl << endl;
	cout << "Boltzmann weight exp(- beta * H ), beta = 1/T " << endl << endl;
	cout << "The program uses k_B=1 and mu_B=1 units " << endl;


//Read input informations
	ReadInput.open("input.dat");

	ReadInput >> restart;

//Read seed for random numbers
	if (restart == 0) rnd.Initialize("seed.in");
	if (restart == 1) rnd.Initialize("seed.out");

	ReadInput >> temp;
	beta = 1.0/temp;
	cout << "Temperature = " << temp << endl;

	ReadInput >> nspin;
	cout << "Number of spins = " << nspin << endl;

	ReadInput >> J;
	cout << "Exchange interaction = " << J << endl;

	ReadInput >> h;
	cout << "External field = " << h << endl << endl;
    
	ReadInput >> metro; // if=1 Metropolis else Gibbs

	ReadInput >> nblk;

	ReadInput >> nstep;

	if(metro==1) cout << "The program perform Metropolis moves" << endl;
	else cout << "The program perform Gibbs moves" << endl;
	cout << "Number of blocks = " << nblk << endl;
	cout << "Number of steps in one block = " << nstep << endl << endl;
	ReadInput.close();

//Set all variables to 0
	Reset(0);

//Prepare arrays for measurements
	iu = 0; //Energy
	ic = 1; //Heat capacity
	im = 2; //Magnetization
	ix = 3; //Magnetic susceptibility
 
	n_props = 4; //Number of observables

	if (restart == 1)  {
		//Reading initial configuration from file config.final
		ifstream ReadConf;
		ReadConf.open("config.final");
		for (int i=0; i<nspin; ++i) {
			ReadConf >> s[i];
			cout << s[i] << endl;
		}

		ReadConf.close();
		cout << "Reading initial configuration from file config.final" << endl;
	} 
	else {
		//Remove old measure files
		system ("./clean.sh");
		cout << "Starting with random initial configuration" << endl;
		//Initial configuration (random)
			for (int i=0; i<nspin; ++i) {
				if(rnd.Rannyu() >= 0.5) s[i] = 1.0;
				else s[i] = -1.0;
			}
	}

//Evaluate energy etc. of the initial configuration
	Measure();
/*	ofstream WriteConf;

	WriteConf.open("prova");
WriteConf << scientific << walker[iu]/(double)nspin<< endl;
	for (int i=0; i<nspin; ++i)	WriteConf << s[i] << endl;
  	WriteConf.close();
*/
//Print initial values for the potential energy and virial
	cout << "Initial energy = " << scientific << walker[iu]/(double)nspin << endl << endl;
}


void Move(int metro) {
	int o;
	double p;
	double energy_diff;
	double q;

	for(int i=0; i<nspin; ++i) {
	//Select randomly a particle (for C++ syntax, 0 <= o <= nspin-1)
		o = (int)(rnd.Rannyu()*nspin);
		if(metro==1) { //Metropolis
			energy_diff = 2.0 * (J*s[o] * ( s[Pbc(o-1)] + s[Pbc(o+1)] ) + h*s[o]);
//cout << energy_diff << endl;
			q = exp (-beta*energy_diff);
			double A = min (1., q);
			if (Accept(A)) s[o] = -1.0*s[o];
		}
		else { //Gibbs sampling
			p = 1.0/(1.0 + exp (-2.0*beta*(J * ( s[Pbc(o-1)] + s[Pbc(o+1)] ) + h)));
			double k = rnd.Rannyu();
			if (k<= p) s[o] = 1.0;
			else s[o] = -1.0;
		}
		attempted++;
	}

}

void Measure() {
	int bin;
	double u = 0.0, m = 0.0, u2 = 0.0;

//cycle over spins
	for (int i=0; i<nspin; ++i) {
		u += -J * s[i] * s[Pbc(i+1)] - 0.5 * h * (s[i] + s[Pbc(i+1)]);
//		u2 += (-J * s[i] * s[Pbc(i+1)] - 0.5 * h * (s[i] + s[Pbc(i+1)])) * (-J * s[i] * s[Pbc(i+1)] - 0.5 * h * (s[i] + s[Pbc(i+1)]));
		m += s[i];
	}

	walker[iu] = u;				//Energy
	walker[ic] = u*u;			//Heat
#ifdef MAG_MEAS
	walker[im] = m;				//Magnetization
#endif
	walker[ix] = m*m;		//Magnetic Susceptibility 
}


void Reset(int iblk) {//Reset block averages
   
	if(iblk == 1) {
		for(int i=0; i<n_props; ++i) {
			glob_av[i] = 0;
			glob_av2[i] = 0;
		}
	}

	for(int i=0; i<n_props; ++i) blk_av[i] = 0;
	attempted = 0;
	accepted = 0;
}


void Accumulate(void) { //Update block averages 

	for(int i=0; i<n_props; ++i) blk_av[i] += walker[i];

}


void Averages(int iblk) { //Print results for current block
    
	ofstream Ene, Heat, Mag, Chi;
    
	cout << "Block number " << iblk << endl;
	if (metro==1)	cout << "Acceptance rate " << (double)(accepted)/attempted << endl << endl;
    
	Ene.open("output.ene.dat",ios::app);
	stima_u = blk_av[iu]/(double) (nstep*nspin); //Energy per spin
	glob_av[iu]  += stima_u;
	glob_av2[iu] += stima_u*stima_u;
	err_u=Block_Error(iblk, glob_av[iu],glob_av2[iu]);

	Heat.open("output.heat.dat",ios::app);
//	stima_c = beta*beta * (blk_av[ic]/(double) (nstep*nspin) - stima_u*stima_u); //Heat
	stima_c = beta*beta * (blk_av[ic]/(double) (nstep) - blk_av[iu]*blk_av[iu]/(double)(nstep*nstep))/(double)(nspin); //Heat
	glob_av[ic]  += stima_c;
	glob_av2[ic] += stima_c*stima_c;
	err_c=Block_Error(iblk, glob_av[ic],glob_av2[ic]);

#ifdef MAG_MEAS
	Mag.open("output.mag.dat",ios::app);
	stima_m = blk_av[im]/(double) (nstep*nspin); //Magn per spin
	glob_av[im]  += stima_m;
	glob_av2[im] += stima_m*stima_m;
	err_m=Block_Error(iblk, glob_av[im],glob_av2[im]);
#endif

	Chi.open("output.chi.dat",ios::app);
	stima_x = beta * blk_av[ix]/(double) (nstep*nspin); //Susc per spin
	glob_av[ix]  += stima_x;
	glob_av2[ix] += stima_x*stima_x;
	err_x=Block_Error(iblk, glob_av[ix],glob_av2[ix]);

	Ene << iblk <<  setprecision(10) << scientific << "\t" << glob_av[iu]/(double)iblk << "\t" << err_u << endl;
	Ene.close();
		
	Heat << iblk <<  setprecision(10) << scientific << "\t" << glob_av[ic]/(double)iblk << "\t" << err_c << endl;
	Heat.close();

	Mag << iblk <<  setprecision(10) << scientific << "\t" << glob_av[im]/(double)iblk << "\t" << err_m << endl;
	Mag.close();

	Chi << iblk <<  setprecision(10) << scientific << "\t" << glob_av[ix]/(double)iblk << "\t" << err_x << endl;
	Chi.close();

	cout << "----------------------------" << endl << endl;
}


void ConfFinal(void) {
	ofstream WriteConf;

	cout << "Print final configuration to file config.final " << endl << endl;
	WriteConf.open("config.final");
	for (int i=0; i<nspin; ++i)	WriteConf << s[i] << endl;
  	WriteConf.close();

	rnd.SaveSeed();
}

int Pbc(int i) { //Algorithm for periodic boundary conditions
	if(i >= nspin) i = i - nspin;
	else if(i < 0) i = i + nspin;
	return i;
}


double Block_Error (int block, double sum, double sum2) {
	//block is number of block	
	//sum is cumulative sum
	//sum2 is squared cumulative sum
	if (block == 1) return 0;
	else return sqrt ((sum2/(double)(block) - (sum*sum)/(double)(block*block))/(block-1.));
}

bool Accept (double A) {
	if (A == 1.) {
		accepted++;
		return true;
	}
	else {
		double k = rnd.Rannyu();
		if (k <= A) {
			accepted++;
			return true;
		}
		else return false;
	}
}


/****************************************************************
*****************************************************************
    _/    _/  _/_/_/  _/       Numerical Simulation Laboratory
   _/_/  _/ _/       _/       Physics Department
  _/  _/_/    _/    _/       Universita' degli Studi di Milano
 _/    _/       _/ _/       Prof. D.E. Galli
_/    _/  _/_/_/  _/_/_/_/ email: Davide.Galli@unimi.it
*****************************************************************
*****************************************************************/
