===============================================
****************Exercises_06*******************
********Numerical Simulation Laboratory********
**************Matteo Martinelli****************
===============================================

Metropolis - Ising 1D model


Legend of files:
ISING_1D
	directory with main and input files

Monte_Carlo_ISING_1D.cpp
	main and functions definition

Monte_Carlo_ISING_1D.h
	header with all global variables and functions declaration	

Monte_Carlo_ISING_1D.exe 
	executable

output_*.dat
	files with outputs

input.dat
	file from which input values are read
	
		ReadInput >> restart 				'bool' activates restarting option 
		ReadInput >> temp;					'double' input temperature
		ReadInput >> nspin;					'int' number of spins (if changing remember also to change in Monte_Carlo_ISING_1D.h, where m_spins is defined as 'const int')
		ReadInput >> J;						'double' exchange term in ising model
		ReadInput >> h;						'double' external field in ising model
		ReadInput >> metro;					'bool' if = 1 (activated) using metropolis for sampling, if = 0 using Gibbs sampling method
		ReadInput >> nblk;					'int' number of blocks
		ReadInput >> nstep;					'int' number of steps per block

config.final
	output configuration after simulation (needed to restart)

seed.in
    random seed for generator

Primes
    other seed for random generator
    			
Equilibration
	directory with saved values for equilibration phase analysis

Configs
	directory with equilibrated configurations already printed (speed up the code)


Exercises_06.ipynb 
	Analysis of the data of simulation already performed


How to produce data:
option 'MAG_MEAS'
	if wanted to have a significant result for output.mag.dat turn on the option --> uncomment line 18 of .cpp ('#define MAG_MEAS)
	default = turn on

Monte_Carlo_ISING_1D
	choose input data
	Equilibrate the system (see jupyter-notebook for more information)
	run the simulation, the output file will appear in the same directory 

-clean.sh
	removes all data files and config.final 
	not necessary to run since program calls it if restart = 0

-make clean
	removes. o
	removes executable 
	removes saved seed

